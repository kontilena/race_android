package com.example.race_timofeeva;

public class Data {
    public static String playerName = "Player";
}
