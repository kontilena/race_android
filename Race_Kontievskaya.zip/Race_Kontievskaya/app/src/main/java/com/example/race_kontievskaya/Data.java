package com.example.race_kontievskaya;

public class Data {
    public static String playerName = "Player";
}
